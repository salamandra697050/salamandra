package PetShop;

public interface TranzactionInterface {
	
	public void setTranzactionDate();
	public void employeeTranzaction();
	public void customerTranzaction();

}
