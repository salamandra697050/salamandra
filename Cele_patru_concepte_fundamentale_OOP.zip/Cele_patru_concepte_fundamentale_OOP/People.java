package PetShop;

public interface People {
	
	public void displayEmployee(Employee employeeParameter);
	public void setEmployeeName(String Name);
	public void setHiredate(String Hiredate);
	public void setDateOfBirth(String DateOfBirth);
}
