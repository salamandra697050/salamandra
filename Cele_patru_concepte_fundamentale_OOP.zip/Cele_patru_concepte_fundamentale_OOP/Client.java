package PetShop;

public interface Client extends People{
	
	public void setCustomerName(String CustomerName);
	public void displayCustomer();
	
}
